[CmdletBinding()]
param([string]$CodexDirectory = $env:CODEX_HOME)

$ErrorActionPreference = 'Stop'

if ([string]::IsNullOrWhiteSpace($CodexDirectory)) {
    $profileDirectory = [Environment]::GetFolderPath('UserProfile')
    $CodexDirectory = Join-Path $profileDirectory '.codex'
}

$petSlug = 'conan-detective'
$manifestName = 'pet.json'
$imageName = 'spritesheet.png'
$sourceDirectory = Join-Path (Split-Path -Parent $PSScriptRoot) "assets/$petSlug"
$sourceManifest = Join-Path $sourceDirectory $manifestName
$sourceImage = Join-Path $sourceDirectory $imageName
$manifest = Get-Content -LiteralPath $sourceManifest -Raw -Encoding UTF8 | ConvertFrom-Json
$expectedImageHash = 'BE201F92681A1BBD958DEE099E6D5045A952D84EF84C92CB7CAE8F9064A30F47'

if ([string]::IsNullOrWhiteSpace($manifest.displayName) -or
    $manifest.spriteVersionNumber -ne 2 -or $manifest.spritesheetPath -cne $imageName) {
    throw 'The packaged pet.json does not describe the bundled v2 sprite sheet.'
}
if ((Get-FileHash -LiteralPath $sourceImage -Algorithm SHA256).Hash -ne $expectedImageHash) {
    throw 'The packaged sprite sheet failed its checksum. Extract a fresh copy of the ZIP.'
}
$manifestHash = (Get-FileHash -LiteralPath $sourceManifest -Algorithm SHA256).Hash

$petsDirectory = Join-Path ([IO.Path]::GetFullPath($CodexDirectory)) 'pets'
$destination = Join-Path $petsDirectory $petSlug
$installedManifest = Join-Path $destination $manifestName
$installedImage = Join-Path $destination $imageName

function Test-IdenticalInstallation {
    (Test-Path -LiteralPath $installedManifest -PathType Leaf) -and
    (Test-Path -LiteralPath $installedImage -PathType Leaf) -and
    ((Get-FileHash -LiteralPath $installedManifest -Algorithm SHA256).Hash -eq $manifestHash) -and
    ((Get-FileHash -LiteralPath $installedImage -Algorithm SHA256).Hash -eq $expectedImageHash)
}

if (Test-Path -LiteralPath $destination) {
    if (!(Test-IdenticalInstallation)) {
        throw "A different item already exists at '$destination'. No files were replaced."
    }
    $status = 'already-installed'
} else {
    [IO.Directory]::CreateDirectory($petsDirectory) | Out-Null
    $staging = Join-Path $petsDirectory ('.conan-import-' + [Guid]::NewGuid().ToString('N'))
    [IO.Directory]::CreateDirectory($staging) | Out-Null
    try {
        [IO.File]::Copy($sourceManifest, (Join-Path $staging $manifestName))
        [IO.File]::Copy($sourceImage, (Join-Path $staging $imageName))
        try {
            [IO.Directory]::Move($staging, $destination)
            $status = 'installed'
        } catch [IO.IOException] {
            if (!(Test-IdenticalInstallation)) { throw }
            $status = 'already-installed'
        }
    } finally {
        if ([IO.Directory]::Exists($staging)) {
            [IO.File]::Delete((Join-Path $staging $manifestName))
            [IO.File]::Delete((Join-Path $staging $imageName))
            [IO.Directory]::Delete($staging)
        }
    }
}

[pscustomobject]@{
    status = $status
    directory = $destination
    local_pet_id = "custom:$petSlug"
} | ConvertTo-Json -Compress
